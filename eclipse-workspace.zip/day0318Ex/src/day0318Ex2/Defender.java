package day0318Ex2;

public interface Defender {
	public void defend();
}
