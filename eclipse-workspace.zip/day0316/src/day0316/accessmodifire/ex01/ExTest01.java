package day0316.accessmodifire.ex01;

public class ExTest01 {

	public static void main(String[] args) {
		//Ex01과 같은 패키지, 다른 클래스
		Ex01 ex=new Ex01();
		ex.publicStr="퍼블릭";
		ex.protectedStr="프로텍티드";
		ex.defaultStr="디폴트";
		//ex.privateStr="프라이빗";
			
		
	}

}
