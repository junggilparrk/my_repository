package day0318.robbot3;

public interface Movavle {
	public void move();
}
