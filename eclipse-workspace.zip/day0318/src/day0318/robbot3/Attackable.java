package day0318.robbot3;

public interface Attackable {
	public void attack();
	
}
