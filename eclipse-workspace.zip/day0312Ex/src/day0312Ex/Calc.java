package day0312Ex;

public class Calc {

	
	
	int sum(int a,int b) {
		int k=a+b;
		return k;
	}
	int sub(int a,int b) {
		int k=a-b;
		return k;
	}
}
