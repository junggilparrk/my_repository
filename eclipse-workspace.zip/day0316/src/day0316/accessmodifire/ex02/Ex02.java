package day0316.accessmodifire.ex02;

import day0316.accessmodifire.ex01.Ex01;

public class Ex02 extends Ex01 {

	public void test() {
		publicStr="hi";
		protectedStr="hi";//삭송을 받았기 때문에 변수에 접근이 가능.
//		defaultStr="hi";
//		privateStr="hi";
	}
	
}
