package day0318Ex2;

public class BodyCheck implements Defender{

	@Override
	public void defend() {
		System.out.println("몸으로 막습니다.");
		
	}
	
}
