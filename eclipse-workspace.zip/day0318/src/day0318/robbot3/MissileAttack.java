package day0318.robbot3;

public class MissileAttack implements Attackable{
	public void attack() {
		System.out.println("미사일 공격을 한다.");
	}

}
 