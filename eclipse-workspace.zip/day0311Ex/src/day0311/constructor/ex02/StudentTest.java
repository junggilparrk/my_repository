package day0311.constructor.ex02;

public class StudentTest {

	public static void main(String[] args) {
		Student st= new Student("스물다섯번째 밤",10);
		System.out.println(st.name);
	}

}
