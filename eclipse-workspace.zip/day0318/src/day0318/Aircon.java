package day0318;

public class Aircon {
	
	public void turnOn() {
		//에어컨 켜는 기능
		System.out.println("냉각기를 이용한다.");	
		System.out.println("실외기를 돌린다.");
		System.out.println("에어콘을 켠다.");
	}
	
	//티비 끄는 기능
	public void turnOff() {
		System.out.println("실외기를 끈다.");
		System.out.println("에어콘을 끈다.");
	}
	
}
