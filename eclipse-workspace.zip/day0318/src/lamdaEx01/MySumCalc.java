package lamdaEx01;

public class MySumCalc implements Sum {

	@Override
	public int sum(int num1, int num2) {
		return num1+num2;
	}

}
