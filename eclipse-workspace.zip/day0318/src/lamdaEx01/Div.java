package lamdaEx01;

public interface Div {
	public int div(int a,int b);

}
