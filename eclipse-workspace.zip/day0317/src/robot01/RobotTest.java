package robot01;

public class RobotTest {
	public static void main(String[] args) {
		//a
		TeakwonV t=new TeakwonV();
		t.fight();
		
		//b
		Transformer tr=new Transformer();						
		tr.fight();
	}
}
