package lamdaEx01;

public interface Gugudan {
	void getGugu(int dan);

}
