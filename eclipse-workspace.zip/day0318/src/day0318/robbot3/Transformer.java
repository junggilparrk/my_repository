package day0318.robbot3;

public class Transformer extends Robot {
	

	public Transformer(String name,Attackable attack,Movavle move) {
		super(name);
		this.attack=attack;
		this.move=move;
	}


}
  