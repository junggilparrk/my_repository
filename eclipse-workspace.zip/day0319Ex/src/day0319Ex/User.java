package day0319Ex;

public class User {

}
