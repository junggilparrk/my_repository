package day0318.robbot3;

public class TaekwonV extends Robot {
	

	public TaekwonV(String name,Attackable attack,Movavle move) {
		super(name);
		this.attack=attack;
		this.move=move;
	}


	 

}
