package day0310.ex01;

public class CarTest {

	public static void main(String[] args) {
		//클래스를 통해서 Car 객체 생성
		//사용자 정의 자료형
		Car car1;
		//car1 변수에 객체를 생성하여 넣어주자
		car1=new Car();
		//생성된 객체의 필드에 값을 넣어 주자
		car1.color="검정";
		car1.mileage=1000;
		
		System.out.println("car1의 컬러는 "+car1.color);
		System.out.println("car1의 마일리지는 "+car1.mileage);
		
		
		
		Car car2;
		car2=new Car();
		car2.color="파랑";
		car2.mileage=20000;
		
		System.out.println(car2.color);
		System.out.println(car2.mileage);
		
		
	
	}

}
