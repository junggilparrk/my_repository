package day0310Ex;

public class Factrial {

}
