package day0318Ex2;

public class HeadingShoot implements Shooter{

	@Override
	public void shoot() {
		System.out.println("헤딩으로 슛을 넣습니다.");
		
	}

}
