package robot02;

public class Gundam extends Robot {
	
	public Gundam() {
		name="Gundam";
	}
	
	public void attack() {
		System.out.println("펀치로 공격!");	
	}
	
	public void move() {
	System.out.println("걸어서 이동!");
	}
	
}
