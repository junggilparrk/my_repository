package day0312Ex;

public class MyCalc extends Calc{

	
	int mul(int a,int b) {
		int k= a*b;
		return k;
	}
	int div(int a,int b) {
		int k= a/b;
		return k;
	}
}
