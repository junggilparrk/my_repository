package day0316.object.ex01;

public class CarTest {

	public static void main(String[] args) {
		Car c1=new Car("벤츠",10000);
		Car c2=new Car("현대",100000);
		//c1의 브랜드명과 주행거리는 어떻게 되나?
		//c2의 브랜드명과 주행거리는 어떻게 되나?
		System.out.println(c1);
		System.out.println(c2);
	}

}
 