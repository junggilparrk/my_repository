package robot01;

public class Transformer {
	public void fight() {
		System.out.println("트랜스포머가 전투를 시작합니다.");
		System.out.println("미사일 공격!");
		System.out.println("걸어서 이동!");
		System.out.println("미사일 공격!");
		System.out.println("트랜스포머가 전투를 종료합니다.");
	}
	
}
