package interfaveEx02;

public class DannggnTest {

}
