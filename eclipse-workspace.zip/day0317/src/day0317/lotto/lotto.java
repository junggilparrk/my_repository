package day0317.lotto;

public class lotto {
	public static void main(String[] args) {
		//1부터 45까지 값 입력 6자리 숫자 입력
		
		
	}
}
