package day0317.car;

public class CarRun {
	protected Car c;
	
	public CarRun(Car c) {
		c.run();
	}
	
}
