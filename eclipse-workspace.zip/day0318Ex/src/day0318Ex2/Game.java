package day0318Ex2;

public class Game {
	private FifaOnline f1;
	
		public void setFifa(FifaOnline f1) {
			this.f1=f1;
		}
	
		public void playGame() {
			f1.gameStart();
		}
		
	}


