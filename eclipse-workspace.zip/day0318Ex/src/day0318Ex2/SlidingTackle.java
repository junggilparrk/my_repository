package day0318Ex2;

public class SlidingTackle implements Defender{

	@Override
	public void defend() {
		System.out.println("슬라이딩 태클로 막습니다.");
		
	}
	
}
