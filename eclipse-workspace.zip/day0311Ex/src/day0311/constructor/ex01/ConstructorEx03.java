package day0311.constructor.ex01;

public class ConstructorEx03 {
	//매개 변수가 있느 생성자
	public ConstructorEx03(String str) {		
		System.out.println("생성자의 파라미터: " +str);
	}
	
}