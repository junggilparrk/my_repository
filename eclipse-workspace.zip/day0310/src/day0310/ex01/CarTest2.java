package day0310.ex01;

public class CarTest2 {
	public static void main(String[] args) {
		//배열과, 객체를 이용하여 연관성을 만들어 주차
		//배열?:같은 자료형의 모임
		//구조체(객체):다른 자료형의 모임
		Car car1=new Car();
		car1.color="검정";
		car1.mileage=1000;
		
		Car car2=new Car();
		car2.color="노랑";
		car2.mileage=500;
	
		Car car3=new Car();
		car3.color="파랑";
		car3.mileage=10000;
		
		if(car1.color.equals("노랑")){
			car1.mileage+=10;
		}
		if(car2.color.equals("노랑")){
			car2.mileage+=10;
		}
		if(car3.color.equals("노랑")){
			car3.mileage+=10;
		}
		//위 내용은 비교 3번 각각 하는데, 이걸 반복문으로 쓰면 더 편할꺼 같은데??
		//반복문을 쓰려고 했더니.변수명이 다르다.
		//배열로 묶어주자
		//car라는 애들을 담을수 있는 방 3개를 만듬
		Car[] carArr=new Car[3];
		carArr[0]=car1;
		carArr[1]=car2;
		carArr[2]=car3;
		
		for(int i=0;i<carArr.length;i++) {
			if(carArr[i].color.contentEquals("노랑")) {
				carArr[i].mileage+=10;
			}System.out.println(carArr[i].mileage);
		}
		 
		
		Car car5=new Car();
		car5.color="흰색";
		car5.mileage=30000;
		
		Car car6=new Car();
		car6.color="초록색";
		car6.mileage=50000;
		
		Car car7=new Car();
		car7.color="검정색";
		car7.mileage=100000;
		 
		Car carArr2[]={car5,car6,car7};		
		for(int i=0;i<carArr2.length;i++) {
			if(carArr2[i].color.contentEquals("초록색")){
				carArr2[i].mileage+=100;
			}System.out.println(carArr2[i].mileage);
		}
		
		
	}
}
