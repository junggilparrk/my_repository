package day0318.robbot3;

//재사용하기 위해 클래스로 뽑아서 만든다.
public class PunchAttack implements Attackable{
	public void attack() {
		System.out.println("펀치로 공격을 합니다.");
	}

}
 