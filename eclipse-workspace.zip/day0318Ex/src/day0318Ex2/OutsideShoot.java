package day0318Ex2;

public class OutsideShoot implements Shooter{

	@Override
	public void shoot() {
		System.out.println("아웃사이드킥으로 슛을 넣습니다.");
		
	}

}
