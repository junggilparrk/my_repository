package lamdaEx01;

public interface Mul {
	public int mul(int c,int d);

}
