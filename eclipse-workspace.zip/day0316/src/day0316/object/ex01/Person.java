package day0316.object.ex01;

public class Person {

	
	public void doCall(Phone phone) {//사람이 전화를 한다.
		phone.call();
	}
}
