package day0311.constructor.ex01;

public class ConstructorEx02 {
	public ConstructorEx02() {
		System.out.println("기본 생성자 실행");
	}
}