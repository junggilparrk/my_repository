package robot02;

public class TeakwonV extends Robot {
	
	public TeakwonV() {
		name="태권브이";
	}
	
	public void attack() {
		System.out.println("펀치 공격!");	
	}
	
	public void move() {
	System.out.println("날아서 이동!");
	}
	
}
