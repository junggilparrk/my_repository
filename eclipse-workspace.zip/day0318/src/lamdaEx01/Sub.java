package lamdaEx01;

public interface Sub {
	public int Sub(int a,int b);
}
