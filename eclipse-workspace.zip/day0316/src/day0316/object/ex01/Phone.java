package day0316.object.ex01;

public class Phone {
	
	private String name;
	
	
	public Phone(String name) {
		this.name=name;
	}
	
	public void call() {
		System.out.println(name+"으로 전화를 겁니다");
	}
	
}
