package day0318.robbot3;

public class Gundam extends Robot {

	public Gundam(String name,Attackable attack,Movavle move) {
		super(name);
		this.attack=attack;
		this.move=move;
	}
	


}
