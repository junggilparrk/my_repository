package ex01;

public class Hello {
	//java를 실행할 때 가장 먼저 실행되는 아이 
	//main 메서드!
	public static void main(String[]arg) {
		String name;//변수 선언
		name="안녕하세요";//name 변수에 값을 대입한다.(초기화)

		System.out.println(name);//name을 출력
	}

}
