package lamdaEx01;

public interface Sum {
	
	public int sum(int num1,int num2);
	
}
