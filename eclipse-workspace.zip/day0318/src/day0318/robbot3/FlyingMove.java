package day0318.robbot3;

//재사용하기 위해 클래스로 뽑아서 만든다.
public class FlyingMove implements Movavle{
	public void move() {
		System.out.println("날아서 이동합니다.");
	}

}
