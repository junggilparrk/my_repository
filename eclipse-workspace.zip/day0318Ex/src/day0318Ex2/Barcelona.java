package day0318Ex2;

public class Barcelona extends FifaOnline {

	public Barcelona(String name, String player, String character, Shooter shoot, Defender defend) {
		super(name, player, character, shoot, defend);
		
	}

	

	


}
