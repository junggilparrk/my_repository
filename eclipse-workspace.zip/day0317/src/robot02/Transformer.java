package robot02;

public class Transformer extends Robot {
	
	
	public Transformer() {
		name="트랜스포머";
	}
	

	public void attack() {
		System.out.println("미사일 공격!");
		
	}
	public void move() {
		System.out.println("걸어서 이동!");
		
	}
}
 