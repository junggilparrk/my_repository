package day0318Ex2;

public interface Shooter {
	public void shoot();
}
