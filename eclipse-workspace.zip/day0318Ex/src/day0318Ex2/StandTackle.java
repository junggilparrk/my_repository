package day0318Ex2;

public class StandTackle implements Defender{

	@Override
	public void defend() {
		System.out.println("스탠드 태클로 막습니다.");
		
	}
	
}
