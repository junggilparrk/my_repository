package day0316.object.ex01;

public class StudentToStringTest {

	public static void main(String[] args) {
		
		StudentToString sts=new StudentToString();
		System.out.println(sts);
		
		
	}
}
 