package day0317.abstractEx.ex01;

public abstract class Animal {
	//추상 클래스
	//싷제 내용이 없는 메서드를 갖은 클래스.
	//키워드: abstract
	//접근지정자 abstract class 클래스 명
	
	protected String name;
	
	public String getName() {
		return name;
	}
	
	public abstract void bark();
	
}
