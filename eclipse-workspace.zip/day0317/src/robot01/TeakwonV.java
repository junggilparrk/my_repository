package robot01;

public class TeakwonV {
	public void fight() {
		System.out.println("태권브이가 전투를 시작합니다.");
		System.out.println("펀치 공격!");
		System.out.println("날아서 이동!");
		System.out.println("펀치 공격!");
		System.out.println("태권브이가 전투를 종료합니다.");
	}
	
}
