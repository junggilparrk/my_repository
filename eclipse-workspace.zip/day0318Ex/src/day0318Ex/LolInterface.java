package day0318Ex;

public interface LolInterface {

	
	public void go();
	
	public void back();
	
	public void turnLeft();
	
	public void turnRight();
	
	public void skillQ();
	
	public void skillW();
	
	public void skillE();
	
	public void skillR();
	
	public void turnOff();
	
	
}
