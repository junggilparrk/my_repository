package day0318Ex;

public class Lol {

}
