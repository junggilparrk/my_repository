package day0318Ex2;

public class CurbShoot implements Shooter{

	@Override
	public void shoot() {
		System.out.println("감아차기로 슛을 넣습니다.");
		
	}

}
