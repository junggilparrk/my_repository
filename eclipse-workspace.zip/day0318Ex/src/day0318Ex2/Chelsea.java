package day0318Ex2;

public class Chelsea extends FifaOnline{

	public Chelsea(String name, String player, String character, Shooter shoot, Defender defend) {
		super(name, player, character, shoot, defend);
		
	}







	
}
