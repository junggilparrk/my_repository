package day0311.constructor.ex01;

public class ConstructorEx01 {
   //생성자
	//객체를 생성할 때 가장 먼저 호출되는 아이
	//객체의 내용(필드)를 초기화 하기 위한 용도로 사용
	
	//생성자 형식
	//접근지정자 클래스명(){실행문}
	//접근지정자 클래스명(매개변수){실행문}
	
}
