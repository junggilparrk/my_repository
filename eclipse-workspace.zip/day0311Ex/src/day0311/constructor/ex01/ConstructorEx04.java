package day0311.constructor.ex01;

public class ConstructorEx04 {
	public ConstructorEx04() {
		System.out.println("기본 생성자 실행");
	}
	public ConstructorEx04(String str) {
		System.out.println("생성자의 파라미터: "+str);
	}
}